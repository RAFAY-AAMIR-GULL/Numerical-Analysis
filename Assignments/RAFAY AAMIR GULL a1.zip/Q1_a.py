## Python Code
## Rafay Aamir
## BSEE19047



epsilon =1

while True:
    if epsilon+1 <= 1:
        break
    epsilon=epsilon/2
    
epsilon=epsilon*2

print("Epsilon of my Laptop is = ",epsilon)



#         Output

#   Epsilon of my Laptop is =  2.220446049250313e-16
