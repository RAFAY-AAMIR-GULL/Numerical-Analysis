true_Value=0.006737947;
N=20;
sum=1;
%approach1
for i=1:N
    if mod(i,2)==0
        sum=sum+((5^i)/factorial(i));
    else
        sum=sum-((5^i)/factorial(i));
    end
end
fprintf("Approach 1 %.20f",sum);
fprintf("\n")


%approach2
for i=1:N
    sum=sum+((5^i)/factorial(i));
end
sum=1/sum;
fprintf("Approach 2 %.20f",sum);
