Epsilon = 1;
 
while (1)
    if (Epsilon+1) <= 1.0
        break
    end
    Epsilon = Epsilon / 2;
end

Epsilon = 2*Epsilon
