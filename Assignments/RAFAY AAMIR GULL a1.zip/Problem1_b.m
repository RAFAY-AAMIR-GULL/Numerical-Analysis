A=1;    
while 1
    if A<=0
        break
    end
    AMin=A;
    A=A/2;
end
AMin
